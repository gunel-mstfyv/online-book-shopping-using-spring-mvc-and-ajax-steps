package az.developia.bookshoppinggunelm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookshoppingGunelMApplicationTests {

	@Test
	void contextLoads() {
	}

}
